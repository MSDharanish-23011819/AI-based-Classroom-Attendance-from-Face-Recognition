# Face Recognition Attendance System

This is an AI-powered classroom attendance system that uses face recognition to automatically mark student attendance from photos or live camera feed.

## Features

- Student Registration with Face Recognition
- Automatic Attendance Marking from Photos
- Attendance Management Dashboard
- Export Attendance Records to CSV
- Real-time Face Detection and Recognition

## Requirements

- Python 3.8 or higher
- Flask web framework
- face_recognition library
- OpenCV
- SQLAlchemy
- Other dependencies listed in requirements.txt

## Installation

1. Clone this repository:
```bash
git clone <repository-url>
cd face_attendance
```

2. Create a virtual environment and activate it:
```bash
python -m venv venv
source venv/bin/activate  # On Windows, use `venv\Scripts\activate`
```

3. Install the required packages:
```bash
pip install -r requirements.txt
```

4. Create the uploads directory:
```bash
mkdir uploads
```

## Usage

1. Start the Flask application:
```bash
python app.py
```

2. Open your web browser and navigate to `http://localhost:5000`

3. Use the system:
   - Register students using the "Register Student" page
   - Upload classroom photos to mark attendance
   - View and export attendance records from the dashboard

## Project Structure

```
face_attendance/
├── app.py              # Main Flask application
├── database.py         # Database models and configuration
├── requirements.txt    # Project dependencies
├── uploads/           # Directory for storing uploaded photos
└── templates/         # HTML templates
    ├── index.html     # Home page
    ├── register.html  # Student registration page
    └── attendance.html # Attendance view page
```

## Technical Details

- Face detection and recognition using the face_recognition library
- SQLite database for storing student information and attendance records
- Bootstrap 5 for the user interface
- Flask for the web application framework

## Security Considerations

- Input validation for file uploads
- Secure file naming
- Database query protection
- Error handling

## Limitations

- Best results with good lighting conditions
- Clear, front-facing photos recommended for registration
- Performance depends on hardware capabilities