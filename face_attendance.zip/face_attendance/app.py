from flask import Flask, render_template, request, jsonify, send_file
from werkzeug.utils import secure_filename
import os
import cv2
import numpy as np
import mediapipe as mp
from datetime import datetime
from database import db, Student, Attendance
import pandas as pd

# Initialize MediaPipe Face Detection
mp_face_detection = mp.solutions.face_detection
mp_face_mesh = mp.solutions.face_mesh
mp_drawing = mp.solutions.drawing_utils

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///attendance.db'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg'}

db.init_app(app)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def extract_face_features(image_path):
    image = cv2.imread(image_path)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    
    with mp_face_mesh.FaceMesh(
        static_image_mode=True,
        max_num_faces=1,
        min_detection_confidence=0.5) as face_mesh:
        
        results = face_mesh.process(image)
        if not results.multi_face_landmarks:
            return None
            
        # Extract facial landmarks as features
        face_landmarks = results.multi_face_landmarks[0]
        features = []
        for landmark in face_landmarks.landmark:
            features.extend([landmark.x, landmark.y, landmark.z])
        
        return np.array(features)

def compare_faces(known_features, face_features, tolerance=0.4):
    if known_features is None or face_features is None:
        return False
    distance = np.linalg.norm(known_features - face_features)
    return distance < tolerance

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register_student():
    if request.method == 'POST':
        student_id = request.form['student_id']
        name = request.form['name']
        photo = request.files['photo']
        
        if photo and allowed_file(photo.filename):
            filename = secure_filename(f"{student_id}_{photo.filename}")
            photo_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            photo.save(photo_path)
            
            # Extract face features
            face_features = extract_face_features(photo_path)
            
            if face_features is None:
                os.remove(photo_path)
                return jsonify({'error': 'No face detected in the image'}), 400
            # Prevent duplicate student_id
            existing = Student.query.filter_by(student_id=student_id).first()
            if existing:
                # clean up uploaded photo
                os.remove(photo_path)
                return jsonify({'error': 'Student ID already registered'}), 400

            # Save to database (with rollback on failure)
            try:
                student = Student(
                    student_id=student_id,
                    name=name,
                    photo_path=photo_path,
                    face_encoding=face_features.tolist()
                )
                db.session.add(student)
                db.session.commit()
            except Exception as e:
                db.session.rollback()
                # remove saved photo on failure
                if os.path.exists(photo_path):
                    os.remove(photo_path)
                return jsonify({'error': 'Database error during registration', 'details': str(e)}), 500

            return jsonify({'message': 'Student registered successfully'})
            
    return render_template('register.html')

@app.route('/mark-attendance', methods=['POST'])
def mark_attendance():
    if 'photo' not in request.files:
        return jsonify({'error': 'No photo uploaded'}), 400
        
    photo = request.files['photo']
    if photo and allowed_file(photo.filename):
        filename = secure_filename(photo.filename)
        photo_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        photo.save(photo_path)
        
        # Process the image
        image = cv2.imread(photo_path)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        with mp_face_mesh.FaceMesh(
            static_image_mode=True,
            min_detection_confidence=0.5) as face_mesh:
            
            results = face_mesh.process(image)
            
            if not results.multi_face_landmarks:
                os.remove(photo_path)
                return jsonify({'error': 'No faces detected in the image'}), 400
            
            # Get all students
            students = Student.query.all()
            attendance_date = datetime.now().date()
            present_students = []
            
            # Process each detected face
            for face_landmarks in results.multi_face_landmarks:
                # Extract features for the detected face
                features = []
                for landmark in face_landmarks.landmark:
                    features.extend([landmark.x, landmark.y, landmark.z])
                current_face_features = np.array(features)
                
                # Compare with each student
                for student in students:
                    known_features = np.array(student.face_encoding)
                    if compare_faces(known_features, current_face_features):
                        # Record attendance
                        attendance = Attendance(
                            student_id=student.student_id,
                            date=attendance_date,
                            status='Present'
                        )
                        db.session.add(attendance)
                        present_students.append(student.name)
                        break  # Move to next detected face
            
            db.session.commit()
            os.remove(photo_path)
            
            return jsonify({
                'message': 'Attendance marked successfully',
                'present_students': present_students
            })
            
    return jsonify({'error': 'Invalid file format'}), 400

@app.route('/view-attendance')
def view_attendance():
    date = request.args.get('date', datetime.now().date())
    attendance_records = db.session.query(
        Student.name,
        Student.student_id,
        Attendance.status,
        Attendance.date
    ).join(Attendance).filter(Attendance.date == date).all()
    
    return render_template('attendance.html', records=attendance_records, selected_date=date)

@app.route('/export-attendance')
def export_attendance():
    date = request.args.get('date', datetime.now().date())
    
    attendance_data = db.session.query(
        Student.name,
        Student.student_id,
        Attendance.status,
        Attendance.date
    ).join(Attendance).filter(Attendance.date == date).all()
    
    df = pd.DataFrame(attendance_data, columns=['Name', 'Student ID', 'Status', 'Date'])
    csv_file = f'attendance_{date}.csv'
    df.to_csv(csv_file, index=False)
    
    return send_file(
        csv_file,
        mimetype='text/csv',
        as_attachment=True,
        download_name=csv_file
    )

if __name__ == '__main__':
    with app.app_context():
        if not os.path.exists(app.config['UPLOAD_FOLDER']):
            os.makedirs(app.config['UPLOAD_FOLDER'])
        db.create_all()
    app.run(debug=True)